var quoteRepo = [
	{
		author: "Steve Jobs",
		quote:  "Stay hungry.  Stay foolish"
	},
	{
		author: "Steve Jobs",
		quote:  "Design is not just what it looks like and feels like. Design is how it works."
	},
	{
		author: "Steve Jobs",
		quote:  "Sometimes life is going to hit you in the head with a brick. Don't lose faith."
	},
	{
		author: "Steve Jobs",
		quote:  "Sometimes when you innovate, you make mistakes. It is best to admit them quickly, and get on with improving your other innovations."
	},
	{
		author: "Steve Jobs",
		quote:  "Being the richest man in the cemetery doesn't matter to me. Going to bed at night saying we've done something wonderful, that's what matters to me."
	},
	{
		author: "Steve Jobs",
		quote:  "Remembering that you are going to die is the best way I know to avoid the trap of thinking you have something to lose. You are already naked. There is no reason not to follow your heart."
	},
		{
		author: "Stephen Curry's manager",
		quote:  "Are your actions today on par with your dreams for tomorrow?"
	},
		{
		author: "Travis Dumont",
		quote:  "You are responsible for the energy that you have around you!"
	},
		{
		author: "Stephen Curry's manager",
		quote:  "Success is not an accident!"
	}
]