Hi!  The following is a simple random quote generator proof of concept.

It will funtion by loading in a random quote from a built in list of quotes (at present there is only about 6 or 7) and then displaying them out to the field in the middle of the screen.  The program will feature the ability to click a button and load a new quote.  It will also feature the ability to tweet a quote out to twitter!:i
